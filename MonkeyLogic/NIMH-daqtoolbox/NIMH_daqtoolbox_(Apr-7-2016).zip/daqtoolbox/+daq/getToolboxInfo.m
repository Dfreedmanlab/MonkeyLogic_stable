function [name,ver] = getToolboxInfo()

name = 'NIMH daqtoolbox';
ver = '(Apr 7, 2016 build 28)';
