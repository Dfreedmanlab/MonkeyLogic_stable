function [name,ver] = getToolboxInfo()

name = 'NIMH daqtoolbox';
ver = '(Mar 16, 2016 build 26)';
