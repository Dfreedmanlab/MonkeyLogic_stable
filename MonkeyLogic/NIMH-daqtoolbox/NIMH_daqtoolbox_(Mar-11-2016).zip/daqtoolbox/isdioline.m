function tf = isdioline(s) %#ok<INUSD>
    tf = false;
end