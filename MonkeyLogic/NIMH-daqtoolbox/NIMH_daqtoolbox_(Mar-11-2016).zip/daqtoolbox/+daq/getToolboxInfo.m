function [name,ver] = getToolboxInfo()

name = 'NIMH daqtoolbox';
ver = '(Mar 11, 2016 build 25)';
