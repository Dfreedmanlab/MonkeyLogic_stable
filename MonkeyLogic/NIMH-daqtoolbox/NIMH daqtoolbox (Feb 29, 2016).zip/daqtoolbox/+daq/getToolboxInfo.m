function [name,ver] = getToolboxInfo()

name = 'NIMH daqtoolbox';
ver = '(Feb 29, 2016 build 23)';
