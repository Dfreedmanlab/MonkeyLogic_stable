function [name,ver] = getToolboxInfo()

name = 'NIMH daqtoolbox';
ver = '(May 19, 2016 build 29)';
